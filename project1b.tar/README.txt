Name: Robert Nguyen
SID: 803879361
Email: roberttn@ucla.edu

TODO:
- 2 more Querys in query.sql.
- Enforcing Data Integrity


References:
developer.mozilla.org/en-US/

